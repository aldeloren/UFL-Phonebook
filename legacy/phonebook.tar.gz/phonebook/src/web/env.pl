#	22 Sept 2000 - env.pl
#		       set up environment info	- MHK
#

$|=1;
#
#	Included by CGI scripts to define essential
#	environment variables when executed thru the web
#	server
#

BEGIN {
	$ENV{USER} = 'phbook';
	$home = "/home/phbook";
	unless ($ENV{HOME} eq $home)  {
	  $ENV{HOME} = $home;
	  $ENV{PATH} .= ":/usr/local/bin:$home/bin";
	}
	push (@INC, "$home/lib");

	open (LOG, ">>$home/log/errors");
	open (STDERR, ">&LOG");
}
