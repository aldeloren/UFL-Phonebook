package Ldap;

use LDAPbase;
use Carp;

@ISA = qw(LDAPbase);

my $HOST = 'ldap.ufl.edu';
my $BASE = 'dc=ufl,dc=edu';

my $ldap = __PACKAGE__->bind($HOST) || die __PACKAGE__->error;

sub connection		{ return $ldap; }
sub base		{ return $BASE; }

1;

