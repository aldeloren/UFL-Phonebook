#!/usr/local/bin/perl
#
#	Pbquery.pm
#
#	Module for a phone book query.
#
#	Provides an ldap filter that corresponds to the query
#	provided.
#
#	28 Sep 2000
#	23 Oct 2000 - change filter for lastnames to use cn
#		field rather than sn field
#	20 Jan 2002 - changed "givenname" to "givenName" for
#		upgrade to new ldap server
#

package Pbquery;

use strict;
use locale;

#
#	new()
#
#	Make a new object for the given query.
#

sub new {
    my ($class, $query) = @_;
    my $new = { 'query'=>$query };
    bless $new, $class;
    return $new;
}

#
#	edited()
#
#	Return edited version of the query.
#

sub edited {
    my $self = shift;
    
    my $query = $self->query;
    
    #
    #	remove extraneous blanks
    #
    
    $query =~ s/^\s+//g;
    $query =~ s/\s+$//g;
     
    #
    #	anything left?
    #
    
    if (!$query) {
        $self->error('This is an empty (null) query');
        return undef;
    }

    $query = lc($query);		# downcase it

    #
    #	Check for invalid characters. 
    #

    if ($query =~ m/[^a-z0-9 ._\'*\-\@]/) {
        $self->error ("Invalid characters in query\n");
        return undef;
    }

    $query =~ s/\s+/ /go;		# compress multiple blanks

    return $query;
    
}

#
#	error()
#
#	Stores/gets error message
#

sub error {
    my $self = shift;
    if (@_) {
        $self->{'error'} = shift;
    }
    
    return $self->{'error'};
}

#
#	filter()
#
#	Make a filter suitable for ldap for the query
#	for this object.
#

sub filter {
    my $self = shift;
    
    my $query = $self->edited ||
        return undef;

    my @query = split ('\s+', $query);
    my $count = @query;
    my $filter;

    #
    #	How the filter is formed will depend on whether the
    #	request looks like an email address and how many 
    #	tokens are in the query.
    #
    #
    #	Anything with an "@" searches only the ldap mail
    #	field.
    #
    #	Note that all surnames are searched for in the "cn" field.
    #	This will duplicate the behavior of the old ph directory
    #	and will match on middle names as well as last names.
    #	

    if ($query =~ m/\@/) {
        if ($count == 1) {
            my $email = shift @query;
            $filter = "(mail=$email)";
        }
    
        else {
            $self->error ("Invalid query for email address");
            return undef;
        }
    }
    
    #
    #	One token
    #
    #	Assume we are looking for
    #
    #		<last name>
    #		<username>  (part of email address)
    #
    #
    
    elsif ($count == 1) {
        my $mail_filter = "mail=$query\@*";
#        my $ln_filter = "|(sn=$query)(sn=* $query)(sn=$query *)(sn=* $query *)";
        my $ln_filter = "|(cn=* $query)(cn=* $query *)";
        
        my $filter = "(|($mail_filter)($ln_filter))";
    
    }
    
    #
    #	Two tokens
    #
    #	Two possible name patterns will be searched for:
    #
    #		<first name><last name>
    #		<last name>
    #
    
    elsif ($count == 2) {
    
        #
        #	Filter for <first name><last name>
        #
        #	First name might be in givenName or cn
        #
        
        my ($fn, $ln) = @query;
        $fn =~ s/^([a-z])\.{0,1}$/$1\*/o;	# wild card for initials
        
        my $fn_filter = "|(givenName=$fn)(cn=$fn *)";
#        my $ln_filter = "|(sn=$ln)(sn=* $ln)(sn=$ln *)(sn=* $ln *)";
        my $ln_filter = "|(cn=* $ln)(cn=* $ln *)";
        my $filter_1 = "&($ln_filter)($fn_filter)";
        
        #
        #	Filter for <last name> where the request is for
        #	a multi-part last name
        #
    
        my $ln = $query;
        my $filter_2 = "|(cn=* $ln)(cn=* $ln *)";
#        my $filter_2 = "|(sn=$ln)(sn=* $ln)(sn=$ln *)(sn=* $ln *)";
        
        $filter = "(|($filter_1)($filter_2))";
        
    }
    
    #
    #	Three or more tokens.
    #
    #	Three possible name patterns will be searched for:
    #
    #		<first name><middle name><last name>
    #		<first name><last name>
    #		<last name>
    #
    
    else {

        #
        #	Filter for <first name><middle name><last name>
        #
        
        my ($fn, $mn, @ln) = @query;
        $fn =~ s/^([a-z])\.{0,1}$/$1\*/o; 	# wild card for initials

        #
        #	middle names are not stored in ldap, so convert
        #	to an initial.
        #
        
        my $mi = substr($mn, 0, 1);
        
        #
        #	last name is whatever is left
        #

        my $ln = join (' ', @ln);
        
        my $fn_filter = "|(&(givenName=$fn)(cn=* $mi *))(cn=$fn $mi *)";
#        my $ln_filter = "|(sn=$ln)(sn=* $ln)(sn=$ln *)(sn=* $ln *)";
        my $ln_filter = "|(cn=* $ln)(cn=* $ln *)";
        my $filter_1 = "&($ln_filter)($fn_filter)";
        
        #
        #	Filter for <first name><last name>
        #

        my ($fn, @ln) = @query;
        my $ln = join (' ', @ln);
        $fn =~ s/^([a-z])\.{0,1}$/$1\*/o; 	# wild card for initials
        my $fn_filter = "|(givenName=$fn)(cn=$fn *)";
#        my $ln_filter = "|(sn=$ln)(sn=* $ln)(sn=$ln *)(sn=* $ln *)";
        my $ln_filter = "|(cn=* $ln)(cn=* $ln *)";
        my $filter_2 = "&($ln_filter)($fn_filter)";
        
        #
        #	Filter for <last name>
        #
        
        my $ln = $query;
#        my $filter_3 = "|(sn=$ln)(sn=* $ln)(sn=$ln *)(sn=* $ln *)";
        my $filter_3 = "|(cn=* $ln)(cn=* $ln *)";
        
        $filter = "(|($filter_1)($filter_2)($filter_3))";
    
    
    }
    
    
}
    
#
#	query()
#
#	Return the query for this object
#

sub query {
    my $self = shift;
    return $self->{'query'};
}

1;

