#
#	Ldapsearch.pm
#
#	Module to retrieve ldap entries based on a standard
#	ldapsearch filter.
#
#	30 Sep 1999
#
#	20 Jan 2002 - modified for new field names in ldap upgrade
#	25 Jan 2002 - more modifications for field names
#	16 Jan 2003 - added hostname to ldapsearch for directory
#		transistion
#


package Ldapsearch;

my $LDAPSEARCH = 'ldapsearch -h old.ldap.ufl.edu';

sub get {
   my ($class, $filter, $maximum) = @_;
   
   $maximum = 25 unless $maximum;
   my $new = [];
   
   unless (open (L, "$LDAPSEARCH \"$filter\"|")) {
      print STDERR "Could not open pipe to to search utility\n";
      return undef;
   }

   #
   #	Loop to read all output from a search.  When we've collected
   #	a complete entry, we can extract the information and
   #	output it.
   #

   my $entry = {};
   my $first = 1;
   while (<L>) {
      last if $count >= $maximum;
      chop;
   
      #
      #	If not a blank line, then we have a line from the
      #	directory to look at.
      #
   
      unless (m/^\s*$/) {
         ($field, $value) = split('=', $_, 2);

         #
         #	The first line read should be the distinguished name
         #	for the entry that follows.  We'll save the cn part as 
         #	the key to the record.
         #
   
         if ($first) {
            $entry = {};
            if (m/^cn\=([a-zA-Z0-9 \-\.]+)\,/) {
               $entry->{'rdn'} = $1;
               $first = 0;
            }
            else {
               print STDERR "Error in distinguished name: $_\n";
            }
            next;
         }
   
         #
         #	If the current field is 'cn', we might want to save it as
         #	the name of the person for the entry.  The 'cn' can have
         #	multiple values, some of which are not useful for displaying
         #	the person's name.  The best choice will be the one with
         #	the blanks.
         #
   
         if ($field eq 'cn') {
            unless ($value =~ m/ /) {
               $field = 'alias';
            }
         }
         $entry->{$field} = $value;
      }

      #
      #	If this line is blank or we are at the end of the file,
      #	then we should have read in a complete entry.  The information
      #	collected will be output as a single line.
      #
   
      if (m/^\s*$/ || eof(L)) {
  
         $type = $entry->{'objectClass'};
        
         #
         #	Process an entry for a person.
         #
      
         if ($type =~ m/Person/) {
      
            #
            #	Make a description for this person out of what
            #	we can find in the title, department, or curriculum
            #
         
            $description = $entry->{'title'};
            if ($entry->{'department'}) {
               $description .= ($description ? ', ' : '');
               $description .= $entry->{'department'};
            }
            if ($entry->{'curriculum'}) {
               $description .= ($description ? ', ' : '');
               $description .= 'Student: ';
               $description .= $entry->{'curriculum'};
            }
         
            ($givenname) = split(/\s+/, $entry->{'cn'});
            $entry->{'name'} = $entry->{'sn'} . ', ' . $givenname;

         }
      
         #
         #	Process a mail alias entry
         #
      
         elsif ($type eq 'mailAlias') {
            $description = $entry->{'description'};
            $description = $name unless $description;
         }
 
         else {
            print STDERR "Unrecognized object class: $type\n";
            next;
         }
         
         $entry->{'description'} = $description;
         bless $entry, $class;
         push (@$new, $entry);
         $entry = {};
      
         $count++;
         undef $name;
         undef $key;
         $first = 1;
      }

   }

   close (L);

   return $new;
   
}

sub cn {
   my $self = shift;
   return $self->{'cn'};
}

sub createtimestamp {
   my $self = shift;
   return $self->{'createtimestamp'};
}

sub curriculum {
   my $self = shift;
   return $self->{'curriculum'};
}

sub department {
   my $self = shift;
   return $self->{'department'};
}

sub description {
   my $self = shift;
   return $self->{'description'};
}

sub givenname {
   my $self = shift;
   return $self->{'givenName'};
}

sub homephone {
   my $self = shift;
   return $self->{'homePhone'};
}

sub homepostaladdress {
   my $self = shift;
   return $self->{'homePostalAddress'};
}

sub homepageurl {
   my $self = shift;
   return $self->{'homePageURL'};
}

sub mail {
   my $self = shift;
   return $self->{'mail'};
}

sub modifytimestamp {
   my $self = shift;
   return $self->{'modifytimestamp'};
}

sub name {
   my $self = shift;
   return $self->{'name'};
}

sub objectclass {
   my $self = shift;
   return $self->{'objectClass'};
}

sub officebuilding {
   my $self = shift;
   return $self->{'officeBuilding'};
}

sub postaladdress {
   my $self = shift;
   return $self->{'postalAddress'};
}

sub rdn {
   my $self = shift;
   return $self->{'rdn'};
}

sub sn {
   my $self = shift;
   return $self->{'sn'};
}

sub telephonenumber {
   my $self = shift;
   return $self->{'telephoneNumber'};
}

sub title {
   my $self = shift;
   return $self->{'title'};
}

sub uid {
   my $self = shift;
   return $self->{'uid'};
}

1;
