#
#	Hide.pm
#
#	Used to obscure the UF ID.
#
#	So this isn't really encryption, but the UF ID is visible
#	in ldap for anyone to see so this is actually only
#	a cosmetic fix.
#

use strict;

my $mask = 56347812;			# use for exclusive or

sub hide {
    my $string = shift;
    $string =~ m/^\d{8}$/ || return $string;
    my $masked = sprintf "%9.9o", $string ^ $mask;
    $masked =~ tr/0-9/TSJWHEVN/;
    return $masked;
}


sub reveal {
    my $string = shift;
    $string =~ m/^[A-Z]+$/ || return $string;
    $string =~ tr/TSJWHEVN/0-7/;
    my $unmasked = sprintf "%8.8d", oct($string) ^ $mask;
    return $unmasked;
}
  
1;
