#
#	LDAPbase.pm
#
#	A base class for other classes that need access to an
#	LDAP server.
#
#	This class provides the basic query and modification functions,
#	the superclass must maintain and provide the server
#	connection.
#
#	18 Jan 2003
#
#	23 Jan 2003 - added size limit test
#

package LDAPbase;

use Net::LDAP qw(LDAP_SIZELIMIT_EXCEEDED);
use Carp;
use strict;

#
#	Used to return an error message to the caller.
#

my $error_message;

sub error {
    shift;
    @_ && ($error_message = shift);
    return $error_message;
}

#
#	This flag and method used to let the caller check for
#	a size limit problem.
#

my $size_limit;

sub size_limit {
   return $size_limit;
}

#
#	bind()
#
#	Class method to bind to the server.
#

sub bind {
    my ($class, $host, $dn, $password) = @_;

    my $ldap = Net::LDAP->new($host) ||
        die "Error connecting to $host";

    my $bind = ($dn && $password) ?
        $ldap->bind($dn, password=>$password) :
        $ldap->bind;

    $bind->code &&
        die "Error binding to ldap server at $host";

    return $ldap;    
    
}

#
#	get_config()
#
#	Class method to read a configuration file consisting of
#	lines like:
#
#		name=value
#
#	Can be used by the super class to get configuration info,
#	this module doesn't access anything in the file.
#

sub get_config {
    my ($class, $file) = @_;
    
    my $config = {};
    open (F, "<$file") || die 'Could not open configuration file';
    while (<F>) {
        chop;
        next unless $_;
        next if m/\s+\#/;
        my ($name, $value) = split('=', $_, 2);
        $$config{$name} = $value;
    }
    close F;
    
    return $config;
}

sub add_entry {
    my ($class, $dn, $attrs) = @_;
    ($dn && $attrs) || croak 'Arguments missing';
    
    my $ldap = $class->connection;
    my $result = $ldap->add ($dn, attrs=>[%$attrs]);

    if ($result->code) {
        $class->error($result->error);
        return 0;
    }

    return 1;
    
}

#
#	search()
#
#	Class method to do a search and return a list of
#	objects containing the results.
#

sub search {
    my ($class, $filter, $limit) = @_;
    
    $filter || croak 'Filter argument missing';

    my $base = $class->base;    
    my $ldap = $class->connection;
    my $mesg = $ldap->search(
        base=>$base,
        filter=>$filter,
        sizelimit=>($limit || 0)
    );
    
    #
    #	Check the result code for the search.
    #
    #	If a size limit is indicated, there can still be results,
    #	but we'll set a flag for the caller to test.
    #

    my $code = $mesg->code;
    $size_limit = ($code == LDAP_SIZELIMIT_EXCEEDED ? 1 : 0);
    if ($code && !$size_limit) {
        $class->error($mesg->error);
        return undef;
    }
    
    my $list = [];
    foreach my $entry ($mesg->entries) {
        my $new = { entry=>$entry };
        bless $new, $class;
        push (@$list, $new);
    }
    
    if (! @$list) {
        $class->error('None found');
        return 0;
    }
    
    return $list;
}

#
#	Instance methods from here down.
#

#
#	We don't actually inherit from Net::LDAP::Entry, but
#	we use a few methods directly from the entry object.
#

sub attributes		{ return ((shift)->{'entry'})->attributes; }
sub dn			{ return ((shift)->{'entry'})->dn; }
sub exists		{ return ((shift)->{'entry'})->exists; }

#
#	delete()
#
#	Deletes this entry.
#

sub delete {
    my $self = shift;
    my $entry = $$self{'entry'};
    my $ldap = $self->connection;
    return $ldap->delete($entry);
}

sub get_value {
    my ($self, $name) = @_;
    return ($$self{'entry'})->get_value($name);
}

sub delete_value {
    my ($self, $name, $value) = @_;
    ($name && $value) || croak 'Arguments missing';
    my @value = $self->get_value($name);
    
    my $new = [];
    my $found = 0;
    foreach (@value) {
        if ($_ eq $value) {
            $found = 1;
        }
        else {
            push (@$new, $_);
        }
    }
    
    $found || return 0;
    
    my $entry = $$self{'entry'};
}

sub replace_attr {
    my ($self, $attr, $old, $new) = @_;

    my @new_value;
    my @old_value = $self->get_value($attr);
    my $found = 0;
    foreach (@old_value) {
        if ($_ eq $old) {
            push (@new_value, $new);
            $found = 1;
        }
        else {
            push (@new_value, $_);
        }
    }
    
    if (! $found) {
        $self->error ('Old value not found');
        return 0;
    }

    my $entry = $$self{'entry'};
    $entry->replace ($attr => \@new_value);
    
    my $ldap = $self->connection;
    my $mesg = $entry->update($ldap);
    if ($mesg->code) {
        $self->error($mesg->error);
        return 0;
    }
    
    return 1;

}


1;

__END__

=head1 NAME

LDAPbase.pm - base class for various LDAP interfaces

=head1 SYNOPSIS

	package Myclass;
	@ISA = qw(LDAPbase);

	sub base { returns the base }
	sub connection { returns a connection }

	$ldap = Myclass->bind(host [,dn, password])
	$list = Myclass->search(filter [,limit])
	$rc = Myclass->add_entry(name, attr)
	Myclass->error
	Myclass->size_limit

	$entry->dn
	$entry->exists(name)
	$entry->get_value(name)
	$entry->attributes

	$entry->delete (name, attr)
	$entry->replace (name, oldattr, newattr)

=head1 DESCRIPTION

This class contains functions witch call the B<Net::LDAP> modules.
This class cannot be used by itself, it must be inherited by
some derived class that supports more specific ldap functions.

=over 25

=item B<Myclass-E<gt>bind>

should be called by the superclass to bind a connection to the
ldap server.
The returned value is the object for the connection and should
be returned by the B<connection> method.

=item B<Myclass-E<gt>search>

returns a reference to a list of entries returned for the
specified I<filter>.
If I<limit> is specified, this is the maximum number of entries
to return.
Returns 0 if none found, B<undef> for other errors.

=item B<Myclass-E<gt>add_entry>

adds a new entry the ldap directory.
The I<dn> must be the complete distinguished name.
The I<attr> argument is a reference to a hash of the attributes
to add.
The value assigned to each attribute can either be a scalar
or a reference to an array of values.

=item B<Myclass-E<gt>error>

returns the text of any error message associated with a
bad return from B<search>.

=item B<Myclass-E<gt>size_limit>

returns a true value if a size limit was reached on the search.
Entries are still returned, but the result won't be complete.

=item B<$entry-E<gt>dn> 

returns the distinguished name (dn) for this entry.

=item B<$entry-E<gt>exists>

returns true if the attribute I<name> exists in this entry.

=item B<$entry-E<gt>get_value>

returns the value or values for the attribute specified by I<name>.
Returns an array of values if the caller wants an array, otherwise
it returns the first value.
It will will return an empty list or a null value
if the named attribute is not actually in the entry,
a reference to an empty list is returned.
Use B<name_exists> if you really want to know if it's there.

=item B<$entry-E<gt>attributes>

returns a list of attribute names in the entry.

=back

I<Last update: January 23, 2003>
