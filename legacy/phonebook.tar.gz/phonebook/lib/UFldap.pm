
package UFldap;

use LDAPbase;
use Carp;

@ISA = qw(LDAPbase);

my $HOST = 'ldap.ufl.edu';
my $BASE = 'dc=ufl,dc=edu';

my $ldap;

sub connection {
    $ldap && return $ldap;
    $ldap = __PACKAGE__->bind($HOST) || die __PACKAGE__->error;
    return $ldap;
}
sub base		{ return $BASE; }

1;

