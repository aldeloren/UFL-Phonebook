#!/usr/local/bin/perl
#
#	Filter.pm
#
#	Module for a phone book query.
#
#	Provides an ldap filter that corresponds to the query
#	provided.
#
#	28 Sep 2000
#	23 Oct 2000 - change filter for lastnames to use cn
#		field rather than sn field
#	20 Jan 2002 - changed "givenname" to "givenName" for
#		upgrade to new ldap server
#
#	22 Jan 2003 - this is new version of the module Pbquery
#		for the new UF ldap
#

package Filter;

use strict;
use locale;

#
#	Common restriction applied to all filters.
#

my $aff_attr = 'eduPersonPrimaryAffiliation';
my $exclude = "|($aff_attr=-*-)($aff_attr=affiliate)";
my $restrict = "&(ou=People)(!($exclude))";

#
#	new()
#
#	Make a new object for the given query.
#

sub new {
    my ($class, $query) = @_;
    my $new = { 'query'=>$query };
    bless $new, $class;
    return $new;
}

#
#	edited()
#
#	Return edited version of the query.
#

sub edited {
    my $self = shift;
    
    my $query = $self->query;
    
    #
    #	remove extraneous blanks
    #
    
    $query =~ s/^\s+//g;
    $query =~ s/\s+$//g;
     
    #
    #	anything left?
    #
    
    if (!$query) {
        $self->error('This is an empty (null) query');
        return undef;
    }

    $query = lc($query);		# downcase it

    #
    #	Check for invalid characters. 
    #

    if ($query =~ m/[^a-z0-9 ._\'*\-\@]/) {
        $self->error ("Invalid characters in query\n");
        return undef;
    }

    $query =~ s/\s+/ /go;		# compress multiple blanks

    return $query;
    
}

#
#	error()
#
#	Stores/gets error message
#

sub error {
    my $self = shift;
    if (@_) {
        $self->{'error'} = shift;
    }
    
    return $self->{'error'};
}

#
#	filter()
#
#	Make a filter suitable for ldap for the query
#	for this object.
#

sub filter {
    my $self = shift;
    
    my $query = $self->edited ||
        return undef;

    my @query = split ('\s+', $query);
    my $count = @query;
    my $filter;

    #
    #	How the filter is formed will depend on whether the
    #	request looks like an email address and how many 
    #	tokens are in the query.
    #
    #
    #	Anything with an "@" searches only the ldap mail
    #	field.
    #
    #	Note that all surnames are searched for in the "cn" field.
    #	This will duplicate the behavior of the old ph directory
    #	and will match on middle names as well as last names.
    #	

    if ($query =~ m/\@/) {
        if ($count == 1) {
            my $email = shift @query;
            $email =~ s/\*//go;			# no wild cards in email
            $filter = "mail=$email";
        }
    
        else {
            $self->error ("Invalid query for email address");
            return undef;
        }
    }
    
    #
    #	One token
    #
    #	Assume we are looking for
    #
    #		<last name>
    #		<username>  (part of email address)
    #
    #
    
    elsif ($count == 1) {
    
        #
        #	If there's a wild card in the query, only search
        #	the cn
        #
        
        if ($query =~ m/\*/) {
#            $query =~ s/\**$/\*/o;		# add wild card on first name
            $filter = "cn=$query";
        }
        else {
            my $mail_filter = "mail=$query\@*";
            my $username_filter = "uid=$query";
            my $ln_filter = 'cn=' .  uc($query) . ',*';
            $filter = "|($mail_filter)($username_filter)($ln_filter)";
        }
    
    }
    
    #
    #	Two tokens
    #
    #	Two possible name patterns will be searched for:
    #
    #		<first name><last name>
    #		<last name>
    #
    
    elsif ($count == 2) {
    
        #
        #	Filter for <first name><last name>
        #
        #	First name might be in givenName or cn
        #
        
        my ($fn, $ln) = @query;
        $fn =~ s/\.$//o;			# remove trailing period
#        $fn =~ s/^([a-z])\.{0,1}$/$1\*/o; 	# wild card for initials
        $fn =~ s/\**$/\*/o;			# add wild card on first name
        my $filter_1 = "cn=$ln,$fn";
        
        #
        #	Filter for <last name> where the request is for
        #	a multi-part last name
        #
    
        my $ln = $query;
        my $filter_2 = "cn=$ln,*";
        
        $filter = "|($filter_1)($filter_2)";
        
    }
    
    #
    #	Three or more tokens.
    #
    #	Three possible name patterns will be searched for:
    #
    #		<first name><middle name><last name>
    #		<first name><last name>
    #		<last name>
    #
    
    else {

        #
        #	Filter for <first name><middle name><last name>
        #
        
        my ($fn, $mn, @ln) = @query;
        $fn =~ s/\.$//o;			# remove trailing period
        $mn =~ s/\.$//o;			# remove trailing period
        $fn =~ s/\**$/\*/o;			# add wild card on first name
        $mn =~ s/\**$/\*/o;			# add wild card on middle

        #
        #	last name is whatever is left
        #

        my $ln = join (' ', @ln);
        my $filter_1 = "cn=$ln,$fn $mn";
        
        #
        #	Filter for <first name><last name>
        #

        my ($fn, @ln) = @query;
        $fn =~ s/\.$//o;			# remove trailing period
        $fn =~ s/\**$/\*/o;			# add wild card on first name
        my $ln = join (' ', @ln);
        my $filter_2 = "cn=$ln,$fn";
        
        #
        #	Filter for <last name>
        #
        
        my $ln = $query;
        my $filter_3 = "cn=$ln,*";
        
        $filter = "|($filter_1)($filter_2)($filter_3)";
    
    
    }

    return "(&($filter)($restrict))";
    
    
}
    
#
#	query()
#
#	Return the query for this object
#

sub query {
    my $self = shift;
    return $self->{'query'};
}

1;

