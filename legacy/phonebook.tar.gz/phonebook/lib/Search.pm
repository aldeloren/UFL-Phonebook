#
#	Searchlist.pm
#
#	Does an ldap search, returns a list of entries found.
#
#	Each entry is just one line containing the essential
#	information:
#
#		name:title:email:key
#

package Search;

use UFldap;
use Carp;

@ISA = qw(UFldap);

sub list {
    my ($class, $filter, $max) = @_;
    $filter || croak 'Argument missing';
    
    $max = $max || 25;
    
    my $list = __PACKAGE__->search($filter, $max);
    
    my $result = [];
    foreach my $entry (@$list) {
        my $name = $entry->get_value('displayName');
        my $aff = $entry->get_value('eduPersonPrimaryAffiliation');
        my $title = $entry->get_value('title');
        my $mail = $entry->get_value('mail');
        my $key = $entry->get_value('uflEduUniversityId');

        my @desc = ($aff);
        if ($title ne STUDENT) {
            push @desc, $title;
        }

        my $desc = join(', ', @desc);        
        push (@$result, "$name;$desc;$mail;$key");
    }

    return $result;
    
}

1;

